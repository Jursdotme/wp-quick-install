<?php 

class Messager extends WP_Widget {

	function __construct()
	{
		$params = array(
				'description' => 'Short description of the Widget',
				'name' => 'Messager (Toro)'
			);

			parent::__construct('Messager', '', $params);
	}

	public function form($instance)
	{
		// print_r($instance);
		extract($instance);
		?>
		<p>
			<label for="<?php echo $this->get_field_id('title'); ?>">Title: </label>
			<input
				class="widefat"
				id="<?php echo $this->get_field_id('title'); ?>"
				name="<?php echo $this->get_field_name('title'); ?>"
				value="<?php if( isset($title) ) echo esc_attr($title); ?>" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id('text'); ?>">Text: </label>
			<textarea 
				class="widefat"
				rows="10"
				id="<?php echo $this->get_field_id('text'); ?>"
				name="<?php echo $this->get_field_name('text'); ?>"><?php if( isset($text) ) echo esc_attr($text); ?></textarea>
		</p>
		<?php
	}

	public function widget($args, $instance)
	{		
		extract($args);
		extract($instance);

		$title = apply_filters('widget_title', $title);
		$text = apply_filters('widget_text', $text);

		echo $before_widget;
			echo $before_title . $title . $after_title;
			echo wpautop( $text ); // auto wrap text in <p> tags
		echo $after_widget;
	}

	// Updating widget replacing old instances with new

	public function update( $new_instance, $old_instance ) {

		$instance = array();

		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
		$instance['text'] = ( ! empty( $new_instance['text'] ) ) ? strip_tags( $new_instance['text'] ) : '';

		return $instance;

	}


}

add_action('widgets_init', function(){
	register_widget('Messager');
}); ?>