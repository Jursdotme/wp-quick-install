<?php 

class Toro_social_share_Widget extends WP_Widget {

	function __construct()
	{
		$options = array(
				'description' => 'Share Buttons for Social Media',
				'name' => 'Social Share (Toro)'
			);

			parent::__construct('Toro_social_share_Widget', '', $options);
	}

	public function form($instance)
	{
		// print_r($instance);
		extract($instance);
		if ($layout=='') { $layout = 'Horizontal';}
		$instance['layout'] = $layout;
		?>

		<!-- TITLE -->
		<p>
			<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e( 'Title', 'toro' ) ?>: </label>
			<input
				type="text"
				class="widefat"
				id="<?php echo $this->get_field_id('title'); ?>"
				name="<?php echo $this->get_field_name('title'); ?>"
				value="<?php if( isset($title) ) echo esc_attr($title); ?>" />
		</p>
		
		<!-- TWITTER -->
		<p>
			<input class="checkbox"
		        <?php if ( isset( $twitter ) && $twitter=='true' ) { echo 'checked="checked"'; } ?>
		        id = "<?php echo $this->get_field_id( 'twitter' ); ?>"
		        name = "<?php echo $this->get_field_name( 'twitter' ); ?>"
		        value = "true"
		        type = "checkbox"
		    />
		    <label for="<?php echo $this->get_field_id( 'twitter' ); ?>" ><?php _e( 'Show Twitter', 'toro' ); ?></label>
		</p>

		<!-- FACEBOOK -->
		<p>
			<input class="checkbox"
		        <?php if ( isset( $facebook ) && $facebook=='true' ) { echo 'checked="checked"'; } ?>
		        id = "<?php echo $this->get_field_id( 'facebook' ); ?>"
		        name = "<?php echo $this->get_field_name( 'facebook' ); ?>"
		        value = "true"
		        type = "checkbox"
		    />
		    <label for="<?php echo $this->get_field_id( 'facebook' ); ?>" ><?php _e( 'Show Facebook', 'toro' ); ?></label>
		</p>

		<!-- GOOGLE+ -->
		<p>
			<input class="checkbox"
		        <?php if ( isset( $google ) && $google=='true' ) { echo 'checked="checked"'; } ?>
		        id = "<?php echo $this->get_field_id( 'google' ); ?>"
		        name = "<?php echo $this->get_field_name( 'google' ); ?>"
		        value = "true"
		        type = "checkbox"
		    />
		    <label for="<?php echo $this->get_field_id( 'google' ); ?>" ><?php _e( 'Show Google+', 'toro' ); ?></label>
		</p>
		
		<hr>

		<!-- LAYOUT -->
		<p>
      <label for="<?php echo $this->get_field_id('layout'); ?>"><?php _e( 'Layout', 'toro' ) ?>: 
        <select class='widefat' id="<?php echo $this->get_field_id('layout'); ?>"
                name="<?php echo $this->get_field_name('layout'); ?>" type="text">
          <option value='Horizontal'<?php echo ($layout=='Horizontal')?'selected':''; ?>>
            <?php _e( 'Horizontal', 'toro' ) ?>
          </option>
          <option value='Vertical'<?php echo ($layout=='Vertical')?'selected':''; ?>>
            <?php _e( 'Vertical', 'toro' ) ?>
          </option> 
        </select>                
      </label>
     </p>

    <!-- SHOW ICONS -->
		<p>
			<input class="checkbox"
		        <?php if ( isset( $icons ) && $icons=='true' ) { echo 'checked="checked"'; } ?>
		        id = "<?php echo $this->get_field_id( 'icons' ); ?>"
		        name = "<?php echo $this->get_field_name( 'icons' ); ?>"
		        value = "true"
		        type = "checkbox"
		    />
		    <label for="<?php echo $this->get_field_id( 'icons' ); ?>" ><?php _e( 'Show Icons', 'toro' ); ?></label>
		</p>

		<!-- SHOW NAMES -->
		<p>
			<input class="checkbox"
		        <?php if ( isset( $names ) && $names=='true' ) { echo 'checked="checked"'; } ?>
		        id = "<?php echo $this->get_field_id( 'names' ); ?>"
		        name = "<?php echo $this->get_field_name( 'names' ); ?>"
		        value = "true"
		        type = "checkbox"
		    />
		    <label for="<?php echo $this->get_field_id( 'names' ); ?>" ><?php _e( 'Show Names', 'toro' ); ?></label>
		</p>


		<?php
	}

	public function widget($args, $instance)
	{		
		extract($args);
		extract($instance);

		$title = apply_filters('widget_title', $title);

		$this_page = get_permalink( $GLOBALS['post']->ID );

		echo $before_widget;
			echo $before_title . $title . $after_title;

			if ( $layout=='Vertical' ) echo '<div class="btn-group-vertical">';
			if ( $layout=='Horizontal' ) echo '<div class="btn-group">';

				if ( ! empty($twitter) ) { ?> 
					<a href='https://twitter.com/share?url=<?php $this_page; ?>' class='btn btn-twitter twitter' target='_blank'>
						<?php if (!$icons == 0) { ?>
							<span class='fa fa-twitter'></span>
							<?php } ?> 
							<?php if (!$names == 0) { ?> Twitter <?php } ?>
					</a>
				<?php } ?>

				<?php if ( ! empty($facebook) ) { ?> 
					<a href='https://www.facebook.com/sharer/sharer.php?u="<?php $this_page; ?>' class='btn btn-facebook facebook' target='_blank'>
						<?php if (!$icons == 0) { ?>
							<span class='fa fa-facebook'></span>
						<?php } ?> 
						<?php if (!$names == 0) { ?> Facebook <?php } ?>
					</a>
				<?php } ?>

				<?php if ( ! empty($google) ) { ?> 
					<a href="#" onclick="popUp=window.open('https://plus.google.com/share?url=<?php echo $this_page ?>', 'popupwindow', 'scrollbars=yes,width=800,height=400');popUp.focus();return false" class='btn btn-google-plus googleplus'>
						<?php if (!$icons == 0) { ?>
							<span class='fa fa-google-plus'></span>
						<?php } ?> 
						<?php if (!$names == 0) { ?> Google+ <?php } ?>
					</a>
				<?php }

					

			echo "</div>";
		echo $after_widget;
	}

	// Updating widget replacing old instances with new

	public function update( $new_instance, $old_instance ) {

		$instance = array();

		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
		$instance['twitter'] = ( ! empty( $new_instance['twitter'] ) ) ? strip_tags( $new_instance['twitter'] ) : '';
		$instance['facebook'] = ( ! empty( $new_instance['facebook'] ) ) ? strip_tags( $new_instance['facebook'] ) : '';
		$instance['google'] = ( ! empty( $new_instance['google'] ) ) ? strip_tags( $new_instance['google'] ) : '';
		$instance['layout'] = $new_instance['layout'];
		$instance['icons'] = ( ! empty( $new_instance['icons'] ) ) ? strip_tags( $new_instance['icons'] ) : '';
		$instance['names'] = ( ! empty( $new_instance['names'] ) ) ? strip_tags( $new_instance['names'] ) : '';

		return $instance;

	}


}

add_action('widgets_init', function(){
	register_widget('Toro_social_share_Widget');
}); ?>