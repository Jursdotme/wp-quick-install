<?php 
error_reporting(E_ALL);
/*
Plugin Name: Toro Widgets
Plugin URI: http://jurs.me
Description: Nice to have Widgets for Toro Theme 
Version: 0.1
Author: Rasmus Jürs
Author URI: http://jurs.me
*/

include "includes/wc_widget_class.php"; // Simple Text with a header

include "includes/toro_simple_text_widget.php"; // Simple Text with a header
include "includes/toro_social_share_widget.php"; // Simple Text with a header
include "includes/toro_woocommerce_top_rated.php"; // Simple Text with a header


?>